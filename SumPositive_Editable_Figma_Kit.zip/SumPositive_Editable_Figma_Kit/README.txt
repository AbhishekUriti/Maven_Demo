SUMPOSITIVE EDITABLE FIGMA KIT

OPTION 1 — Native editable text and shapes (recommended)
1. Unzip this folder on your computer.
2. Open a Figma Design file in the desktop app.
3. Open Plugins > Development > Import plugin from manifest.
4. Choose manifest.json from this folder.
5. Run SumPositive Editable Screens from Development plugins.
6. You will get nine desktop screen frames plus a UI Elements sheet.
7. Select any text, field, rectangle or button label in Layers to edit, copy or move it.

OPTION 2 — SVG import
Drag any SVG file onto your Figma canvas and ungroup as needed.
SVG text handling can vary. Use the plugin when you need native editable text.

WHAT IS INCLUDED
Nine recreated desktop layouts, ten SVGs including a separate UI Elements sheet,
and a local Figma development plugin. The plugin makes real text and shape layers.
The supplied official logo is embedded as one image layer.
These are recreated layouts, not pixel-identical conversions of the generated PNGs.
Decorative 3D illustrations from the PNG mockups are not included.
Buttons and fields are visual design elements; application behavior is not implemented.
No network access is used by this plugin. Each run creates a fresh set of frames.
