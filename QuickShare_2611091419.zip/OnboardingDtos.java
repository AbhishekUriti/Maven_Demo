package com.sumpositive.onboarding.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public final class OnboardingDtos {

    private OnboardingDtos() {}

    public record PersonalDetailsDto(
        @NotBlank(message = "Phone number is required")
        String phone,

        @NotNull(message = "Date of birth is required")
        LocalDate dateOfBirth,

        @NotBlank(message = "Residential address is required")
        String residentialAddress,

        @NotBlank(message = "Emergency contact name is required")
        String emergencyContactName,

        @NotBlank(message = "Emergency contact relation is required")
        String emergencyContactRelation,

        @NotBlank(message = "Emergency contact phone is required")
        String emergencyContactPhone,

        String bloodGroup
    ) {}

    public record StepStatusDto(
        String stepKey,
        boolean completed,
        LocalDateTime acknowledgedAt,
        String notes
    ) {}

    public record ChecklistItemDto(
        String itemKey,
        String title,
        boolean completed,
        LocalDateTime completedAt
    ) {}

    public record ChecklistUpdateRequest(
        @NotBlank(message = "Item key is required")
        String itemKey,
        boolean completed
    ) {}

    public record StepAcknowledgeRequest(
        @NotBlank(message = "Step key is required")
        String stepKey,
        String notes
    ) {}

    public record OnboardingProgressSummaryDto(
        int totalSteps,
        int completedSteps,
        int progressPercentage,
        boolean isComplete,
        List<StepStatusDto> steps,
        List<ChecklistItemDto> checklistItems,
        PersonalDetailsDto personalDetails
    ) {}
}
