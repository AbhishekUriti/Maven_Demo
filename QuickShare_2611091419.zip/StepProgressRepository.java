package com.sumpositive.onboarding.repository;

import com.sumpositive.onboarding.entity.StepProgress;
import com.sumpositive.onboarding.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface StepProgressRepository extends JpaRepository<StepProgress, Long> {
    List<StepProgress> findByUser(User user);
    List<StepProgress> findByUserId(Long userId);
    Optional<StepProgress> findByUserIdAndStepKey(Long userId, String stepKey);
}
