package com.sumpositive.onboarding;

import com.sumpositive.onboarding.dto.AuthDtos.RegisterRequest;
import com.sumpositive.onboarding.exception.AppException.BadRequestException;
import com.sumpositive.onboarding.service.AuthService;
import com.sumpositive.onboarding.service.OnboardingService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest
@Transactional
class OnboardingServiceTests {

    @Autowired
    private AuthService authService;

    @Autowired
    private OnboardingService onboardingService;

    @Test
    @DisplayName("Should block final completion if prior steps are incomplete")
    void testPrematureFinalCompletionBlocked() {
        String testEmail = "candidate.test@sumpositive.com";
        authService.register(new RegisterRequest("Candidate Test", testEmail, "Password123"));

        assertThrows(BadRequestException.class, () -> {
            onboardingService.completeFinalStep(testEmail);
        });
    }

    @Test
    @DisplayName("Context loads and AuthService is injected")
    void testContextLoads() {
        assertNotNull(authService);
        assertNotNull(onboardingService);
    }
}
