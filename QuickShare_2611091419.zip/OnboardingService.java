package com.sumpositive.onboarding.service;

import com.sumpositive.onboarding.dto.OnboardingDtos.*;
import com.sumpositive.onboarding.entity.ChecklistItem;
import com.sumpositive.onboarding.entity.PersonalDetails;
import com.sumpositive.onboarding.entity.StepProgress;
import com.sumpositive.onboarding.entity.User;
import com.sumpositive.onboarding.exception.AppException.*;
import com.sumpositive.onboarding.repository.ChecklistItemRepository;
import com.sumpositive.onboarding.repository.PersonalDetailsRepository;
import com.sumpositive.onboarding.repository.StepProgressRepository;
import com.sumpositive.onboarding.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class OnboardingService {

    private final UserRepository userRepository;
    private final PersonalDetailsRepository personalDetailsRepository;
    private final StepProgressRepository stepProgressRepository;
    private final ChecklistItemRepository checklistItemRepository;

    public OnboardingService(UserRepository userRepository,
                             PersonalDetailsRepository personalDetailsRepository,
                             StepProgressRepository stepProgressRepository,
                             ChecklistItemRepository checklistItemRepository) {
        this.userRepository = userRepository;
        this.personalDetailsRepository = personalDetailsRepository;
        this.stepProgressRepository = stepProgressRepository;
        this.checklistItemRepository = checklistItemRepository;
    }

    private User getAuthenticatedUser(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new UnauthorizedException("User not authenticated"));
    }

    @Transactional(readOnly = true)
    public OnboardingProgressSummaryDto getProgress(String email) {
        User user = getAuthenticatedUser(email);
        List<StepProgress> steps = stepProgressRepository.findByUserId(user.getId());
        List<ChecklistItem> checklist = checklistItemRepository.findByUserId(user.getId());

        int totalSteps = 5;
        int completedSteps = (int) steps.stream().filter(StepProgress::isCompleted).count();
        int progressPercentage = (int) (((double) completedSteps / totalSteps) * 100);

        boolean isFinalSubmitted = steps.stream()
                .anyMatch(s -> "STEP_5_FINAL_SUBMIT".equals(s.getStepKey()) && s.isCompleted());

        PersonalDetails details = personalDetailsRepository.findByUserId(user.getId()).orElse(null);
        PersonalDetailsDto detailsDto = null;
        if (details != null) {
            detailsDto = new PersonalDetailsDto(
                    details.getPhone(),
                    details.getDateOfBirth(),
                    details.getResidentialAddress(),
                    details.getEmergencyContactName(),
                    details.getEmergencyContactRelation(),
                    details.getEmergencyContactPhone(),
                    details.getBloodGroup()
            );
        }

        List<StepStatusDto> stepDtos = steps.stream()
                .map(s -> new StepStatusDto(s.getStepKey(), s.isCompleted(), s.getAcknowledgedAt(), s.getNotes()))
                .collect(Collectors.toList());

        List<ChecklistItemDto> checklistDtos = checklist.stream()
                .map(c -> new ChecklistItemDto(c.getItemKey(), c.getTitle(), c.isCompleted(), c.getCompletedAt()))
                .collect(Collectors.toList());

        return new OnboardingProgressSummaryDto(
                totalSteps,
                completedSteps,
                progressPercentage,
                isFinalSubmitted,
                stepDtos,
                checklistDtos,
                detailsDto
        );
    }

    @Transactional
    public PersonalDetailsDto savePersonalDetails(String email, PersonalDetailsDto dto) {
        User user = getAuthenticatedUser(email);
        PersonalDetails details = personalDetailsRepository.findByUserId(user.getId())
                .orElse(new PersonalDetails());

        details.setUser(user);
        details.setPhone(dto.phone());
        details.setDateOfBirth(dto.dateOfBirth());
        details.setResidentialAddress(dto.residentialAddress());
        details.setEmergencyContactName(dto.emergencyContactName());
        details.setEmergencyContactRelation(dto.emergencyContactRelation());
        details.setEmergencyContactPhone(dto.emergencyContactPhone());
        details.setBloodGroup(dto.bloodGroup());
        details.setUpdatedAt(LocalDateTime.now());

        personalDetailsRepository.save(details);

        // Mark Step 2 as completed
        StepProgress step2 = stepProgressRepository.findByUserIdAndStepKey(user.getId(), "STEP_2_PERSONAL_INFO")
                .orElseGet(() -> new StepProgress(user, "STEP_2_PERSONAL_INFO", false));
        step2.setCompleted(true);
        step2.setAcknowledgedAt(LocalDateTime.now());
        stepProgressRepository.save(step2);

        return dto;
    }

    @Transactional
    public StepStatusDto acknowledgeStep(String email, StepAcknowledgeRequest req) {
        User user = getAuthenticatedUser(email);

        if ("STEP_5_FINAL_SUBMIT".equals(req.stepKey())) {
            throw new BadRequestException("Please use the final submit endpoint to complete Step 5.");
        }

        StepProgress step = stepProgressRepository.findByUserIdAndStepKey(user.getId(), req.stepKey())
                .orElseThrow(() -> new ResourceNotFoundException("Step " + req.stepKey() + " not found"));

        step.setCompleted(true);
        step.setAcknowledgedAt(LocalDateTime.now());
        if (req.notes() != null) {
            step.setNotes(req.notes());
        }

        stepProgressRepository.save(step);
        return new StepStatusDto(step.getStepKey(), step.isCompleted(), step.getAcknowledgedAt(), step.getNotes());
    }

    @Transactional
    public ChecklistItemDto updateChecklistItem(String email, ChecklistUpdateRequest req) {
        User user = getAuthenticatedUser(email);

        ChecklistItem item = checklistItemRepository.findByUserIdAndItemKey(user.getId(), req.itemKey())
                .orElseThrow(() -> new ResourceNotFoundException("Checklist item " + req.itemKey() + " not found"));

        item.setCompleted(req.completed());
        item.setCompletedAt(req.completed() ? LocalDateTime.now() : null);
        checklistItemRepository.save(item);

        // Check if all 3 checklist items are completed; if yes, complete Step 4 automatically
        List<ChecklistItem> allItems = checklistItemRepository.findByUserId(user.getId());
        boolean allDone = allItems.stream().allMatch(ChecklistItem::isCompleted);

        StepProgress step4 = stepProgressRepository.findByUserIdAndStepKey(user.getId(), "STEP_4_CHECKLIST")
                .orElseGet(() -> new StepProgress(user, "STEP_4_CHECKLIST", false));
        step4.setCompleted(allDone);
        if (allDone) {
            step4.setAcknowledgedAt(LocalDateTime.now());
        }
        stepProgressRepository.save(step4);

        return new ChecklistItemDto(item.getItemKey(), item.getTitle(), item.isCompleted(), item.getCompletedAt());
    }

    @Transactional
    public OnboardingProgressSummaryDto completeFinalStep(String email) {
        User user = getAuthenticatedUser(email);

        // Enforce business rule: Steps 1-4 must all be complete before Step 5 can finish
        List<StepProgress> steps = stepProgressRepository.findByUserId(user.getId());
        boolean step1Done = steps.stream().anyMatch(s -> "STEP_1_WELCOME".equals(s.getStepKey()) && s.isCompleted());
        boolean step2Done = steps.stream().anyMatch(s -> "STEP_2_PERSONAL_INFO".equals(s.getStepKey()) && s.isCompleted());
        boolean step3Done = steps.stream().anyMatch(s -> "STEP_3_POLICIES".equals(s.getStepKey()) && s.isCompleted());
        boolean step4Done = steps.stream().anyMatch(s -> "STEP_4_CHECKLIST".equals(s.getStepKey()) && s.isCompleted());

        if (!step1Done || !step2Done || !step3Done || !step4Done) {
            throw new BadRequestException("Cannot submit final onboarding: Prior steps (1-4) and all checklist items must be completed first.");
        }

        StepProgress step5 = stepProgressRepository.findByUserIdAndStepKey(user.getId(), "STEP_5_FINAL_SUBMIT")
                .orElseGet(() -> new StepProgress(user, "STEP_5_FINAL_SUBMIT", false));
        step5.setCompleted(true);
        step5.setAcknowledgedAt(LocalDateTime.now());
        stepProgressRepository.save(step5);

        return getProgress(email);
    }
}
