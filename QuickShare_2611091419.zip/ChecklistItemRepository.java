package com.sumpositive.onboarding.repository;

import com.sumpositive.onboarding.entity.ChecklistItem;
import com.sumpositive.onboarding.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface ChecklistItemRepository extends JpaRepository<ChecklistItem, Long> {
    List<ChecklistItem> findByUser(User user);
    List<ChecklistItem> findByUserId(Long userId);
    Optional<ChecklistItem> findByUserIdAndItemKey(Long userId, String itemKey);
}
