package com.sumpositive.onboarding.repository;

import com.sumpositive.onboarding.entity.PersonalDetails;
import com.sumpositive.onboarding.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface PersonalDetailsRepository extends JpaRepository<PersonalDetails, Long> {
    Optional<PersonalDetails> findByUser(User user);
    Optional<PersonalDetails> findByUserId(Long userId);
}
