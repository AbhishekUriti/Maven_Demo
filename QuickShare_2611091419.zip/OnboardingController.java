package com.sumpositive.onboarding.controller;

import com.sumpositive.onboarding.dto.OnboardingDtos.*;
import com.sumpositive.onboarding.service.OnboardingService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/onboarding")
public class OnboardingController {

    private final OnboardingService onboardingService;

    public OnboardingController(OnboardingService onboardingService) {
        this.onboardingService = onboardingService;
    }

    @GetMapping("/progress")
    public ResponseEntity<OnboardingProgressSummaryDto> getProgress(Authentication authentication) {
        return ResponseEntity.ok(onboardingService.getProgress(authentication.getName()));
    }

    @PostMapping("/personal-details")
    public ResponseEntity<PersonalDetailsDto> savePersonalDetails(
            Authentication authentication,
            @Valid @RequestBody PersonalDetailsDto dto) {
        return ResponseEntity.ok(onboardingService.savePersonalDetails(authentication.getName(), dto));
    }

    @PostMapping("/acknowledge-step")
    public ResponseEntity<StepStatusDto> acknowledgeStep(
            Authentication authentication,
            @Valid @RequestBody StepAcknowledgeRequest req) {
        return ResponseEntity.ok(onboardingService.acknowledgeStep(authentication.getName(), req));
    }

    @PatchMapping("/checklist")
    public ResponseEntity<ChecklistItemDto> updateChecklist(
            Authentication authentication,
            @Valid @RequestBody ChecklistUpdateRequest req) {
        return ResponseEntity.ok(onboardingService.updateChecklistItem(authentication.getName(), req));
    }

    @PostMapping("/complete")
    public ResponseEntity<OnboardingProgressSummaryDto> completeOnboarding(Authentication authentication) {
        return ResponseEntity.ok(onboardingService.completeFinalStep(authentication.getName()));
    }
}
