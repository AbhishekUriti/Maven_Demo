package com.sumpositive.onboarding.exception;

import org.springframework.http.HttpStatus;

public final class AppException {

    private AppException() {}

    public static class ResourceNotFoundException extends BaseAppException {
        public ResourceNotFoundException(String message) {
            super(message, HttpStatus.NOT_FOUND);
        }
    }

    public static class ConflictException extends BaseAppException {
        public ConflictException(String message) {
            super(message, HttpStatus.CONFLICT);
        }
    }

    public static class BadRequestException extends BaseAppException {
        public BadRequestException(String message) {
            super(message, HttpStatus.BAD_REQUEST);
        }
    }

    public static class UnauthorizedException extends BaseAppException {
        public UnauthorizedException(String message) {
            super(message, HttpStatus.UNAUTHORIZED);
        }
    }
}
