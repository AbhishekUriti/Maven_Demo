package com.sumpositive.onboarding.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "checklist_items", uniqueConstraints = {
    @UniqueConstraint(columnNames = {"user_id", "item_key"})
})
public class ChecklistItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", referencedColumnName = "id", nullable = false)
    private User user;

    @Column(name = "item_key", nullable = false, length = 50)
    private String itemKey;

    @Column(nullable = false, length = 150)
    private String title;

    @Column(nullable = false)
    private boolean completed = false;

    private LocalDateTime completedAt;

    public ChecklistItem() {}

    public ChecklistItem(User user, String itemKey, String title, boolean completed) {
        this.user = user;
        this.itemKey = itemKey;
        this.title = title;
        this.completed = completed;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public String getItemKey() { return itemKey; }
    public void setItemKey(String itemKey) { this.itemKey = itemKey; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public boolean isCompleted() { return completed; }
    public void setCompleted(boolean completed) { this.completed = completed; }

    public LocalDateTime getCompletedAt() { return completedAt; }
    public void setCompletedAt(LocalDateTime completedAt) { this.completedAt = completedAt; }
}
