package com.sumpositive.onboarding.service;

import com.sumpositive.onboarding.dto.AuthDtos.*;
import com.sumpositive.onboarding.entity.ChecklistItem;
import com.sumpositive.onboarding.entity.StepProgress;
import com.sumpositive.onboarding.entity.User;
import com.sumpositive.onboarding.exception.AppException.*;
import com.sumpositive.onboarding.repository.ChecklistItemRepository;
import com.sumpositive.onboarding.repository.StepProgressRepository;
import com.sumpositive.onboarding.repository.UserRepository;
import com.sumpositive.onboarding.security.JwtUtils;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final StepProgressRepository stepProgressRepository;
    private final ChecklistItemRepository checklistItemRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtils jwtUtils;

    public AuthService(UserRepository userRepository,
                       StepProgressRepository stepProgressRepository,
                       ChecklistItemRepository checklistItemRepository,
                       PasswordEncoder passwordEncoder,
                       JwtUtils jwtUtils) {
        this.userRepository = userRepository;
        this.stepProgressRepository = stepProgressRepository;
        this.checklistItemRepository = checklistItemRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtils = jwtUtils;
    }

    @Transactional
    public AuthResponse register(RegisterRequest req) {
        if (userRepository.existsByEmail(req.email())) {
            throw new ConflictException("An account with email " + req.email() + " already exists");
        }

        User user = new User(
                req.fullName(),
                req.email().toLowerCase().trim(),
                passwordEncoder.encode(req.password())
        );
        user = userRepository.save(user);

        // Seed 5 standard onboarding steps
        List<String> defaultSteps = List.of(
                "STEP_1_WELCOME",
                "STEP_2_PERSONAL_INFO",
                "STEP_3_POLICIES",
                "STEP_4_CHECKLIST",
                "STEP_5_FINAL_SUBMIT"
        );
        for (String stepKey : defaultSteps) {
            stepProgressRepository.save(new StepProgress(user, stepKey, false));
        }

        // Seed 3 standard joining checklist items
        checklistItemRepository.save(new ChecklistItem(user, "ITEM_ID_CARD", "Employee ID & Badge Verification", false));
        checklistItemRepository.save(new ChecklistItem(user, "ITEM_LAPTOP_SETUP", "Development Machine & VPN Provisioning", false));
        checklistItemRepository.save(new ChecklistItem(user, "ITEM_BANK_DETAILS", "Salary Account & Tax Documentation", false));

        String token = jwtUtils.generateToken(user.getEmail());
        return new AuthResponse(token, user.getId(), user.getFullName(), user.getEmail(), user.getRole());
    }

    public AuthResponse login(LoginRequest req) {
        User user = userRepository.findByEmail(req.email().toLowerCase().trim())
                .orElseThrow(() -> new UnauthorizedException("Invalid email or password"));

        if (!passwordEncoder.matches(req.password(), user.getPasswordHash())) {
            throw new UnauthorizedException("Invalid email or password");
        }

        String token = jwtUtils.generateToken(user.getEmail());
        return new AuthResponse(token, user.getId(), user.getFullName(), user.getEmail(), user.getRole());
    }

    public UserProfileResponse getProfile(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        return new UserProfileResponse(user.getId(), user.getFullName(), user.getEmail(), user.getRole());
    }
}
