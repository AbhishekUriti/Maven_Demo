-- Sumpositive Employee Onboarding PostgreSQL Database Schema
DROP TABLE IF EXISTS checklist_items CASCADE;
DROP TABLE IF EXISTS step_progress CASCADE;
DROP TABLE IF EXISTS personal_details CASCADE;
DROP TABLE IF EXISTS users CASCADE;

CREATE TABLE users (
    id BIGSERIAL PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(120) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) DEFAULT 'ROLE_EMPLOYEE' NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE personal_details (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    phone VARCHAR(20),
    date_of_birth DATE,
    residential_address TEXT,
    emergency_contact_name VARCHAR(100),
    emergency_contact_relation VARCHAR(50),
    emergency_contact_phone VARCHAR(20),
    blood_group VARCHAR(10),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE step_progress (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    step_key VARCHAR(50) NOT NULL,
    completed BOOLEAN DEFAULT FALSE NOT NULL,
    acknowledged_at TIMESTAMP,
    notes TEXT,
    CONSTRAINT uq_user_step UNIQUE(user_id, step_key)
);

CREATE TABLE checklist_items (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    item_key VARCHAR(50) NOT NULL,
    title VARCHAR(150) NOT NULL,
    completed BOOLEAN DEFAULT FALSE NOT NULL,
    completed_at TIMESTAMP,
    CONSTRAINT uq_user_item UNIQUE(user_id, item_key)
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_step_progress_user ON step_progress(user_id);
CREATE INDEX idx_checklist_items_user ON checklist_items(user_id);
